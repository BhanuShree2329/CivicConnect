import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, MapPin, MessageSquare, ThumbsUp } from "lucide-react"

const mockIssues = [
  {
    id: 1,
    title: "Broken streetlight on Main Street",
    category: "Infrastructure",
    urgency: "High",
    location: "123 Main Street",
    description: "The streetlight has been out for 3 days, creating safety concerns for pedestrians.",
    date: "2024-01-15",
    status: "In Progress",
    likes: 12,
    comments: 3,
  },
  {
    id: 2,
    title: "Pothole causing traffic issues",
    category: "Transportation",
    urgency: "Medium",
    location: "Oak Avenue & 5th Street",
    description: "Large pothole is causing vehicles to swerve and creating traffic congestion.",
    date: "2024-01-14",
    status: "Reported",
    likes: 8,
    comments: 5,
  },
  {
    id: 3,
    title: "Overflowing trash bins in Central Park",
    category: "Environment",
    urgency: "Low",
    location: "Central Park, Section B",
    description: "Multiple trash bins are overflowing, attracting pests and creating unsanitary conditions.",
    date: "2024-01-13",
    status: "Resolved",
    likes: 15,
    comments: 2,
  },
  {
    id: 4,
    title: "Water main leak flooding sidewalk",
    category: "Utilities",
    urgency: "Critical",
    location: "Pine Street near City Hall",
    description: "Water main break is flooding the sidewalk and affecting nearby businesses.",
    date: "2024-01-16",
    status: "In Progress",
    likes: 23,
    comments: 8,
  },
]

const getUrgencyColor = (urgency: string) => {
  switch (urgency.toLowerCase()) {
    case "critical":
      return "bg-destructive text-destructive-foreground"
    case "high":
      return "bg-orange-500 text-white"
    case "medium":
      return "bg-yellow-500 text-white"
    case "low":
      return "bg-green-500 text-white"
    default:
      return "bg-secondary text-secondary-foreground"
  }
}

const getStatusColor = (status: string) => {
  switch (status.toLowerCase()) {
    case "resolved":
      return "bg-green-100 text-green-800 border-green-200"
    case "in progress":
      return "bg-blue-100 text-blue-800 border-blue-200"
    case "reported":
      return "bg-gray-100 text-gray-800 border-gray-200"
    default:
      return "bg-secondary text-secondary-foreground"
  }
}

export function IssueDashboard() {
  return (
    <section className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-foreground">Community Reports</h2>
        <p className="text-muted-foreground">Track the latest civic issues reported by your community</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {mockIssues.map((issue) => (
          <Card key={issue.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <CardTitle className="text-lg leading-tight">{issue.title}</CardTitle>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    {issue.date}
                  </div>
                </div>
                <Badge className={getUrgencyColor(issue.urgency)}>{issue.urgency}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="h-3 w-3" />
                {issue.location}
              </div>

              <p className="text-sm text-foreground leading-relaxed">{issue.description}</p>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Badge variant="outline" className={getStatusColor(issue.status)}>
                    {issue.status}
                  </Badge>
                  <Badge variant="secondary">{issue.category}</Badge>
                </div>

                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <Button variant="ghost" size="sm" className="h-8 px-2">
                    <ThumbsUp className="h-3 w-3 mr-1" />
                    {issue.likes}
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 px-2">
                    <MessageSquare className="h-3 w-3 mr-1" />
                    {issue.comments}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}
