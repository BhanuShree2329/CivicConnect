"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MapPin, Send, Upload, AlertTriangle } from "lucide-react"

export function IssueForm() {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    location: "",
    urgency: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Submitting issue:", formData)
    // Reset form
    setFormData({
      title: "",
      description: "",
      category: "",
      location: "",
      urgency: "",
    })
  }

  return (
    <Card className="h-fit border-border/50 bg-card/50 backdrop-blur-sm slide-up">
      <CardHeader className="pb-6">
        <CardTitle className="flex items-center gap-3 text-xl">
          <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
            <Send className="h-4 w-4 text-primary" />
          </div>
          Issue Reporting System
        </CardTitle>
        <CardDescription className="text-base">
          Submit detailed civic issues for municipal review and resolution tracking
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-3">
            <Label htmlFor="title" className="text-sm font-medium">
              Issue Title *
            </Label>
            <Input
              id="title"
              placeholder="Concise description of the civic issue"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="h-11 bg-background/50 border-border/50"
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <Label htmlFor="category" className="text-sm font-medium">
                Department *
              </Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger className="h-11 bg-background/50 border-border/50">
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="infrastructure">Infrastructure & Public Works</SelectItem>
                  <SelectItem value="safety">Public Safety & Emergency</SelectItem>
                  <SelectItem value="environment">Environmental Services</SelectItem>
                  <SelectItem value="transportation">Transportation & Traffic</SelectItem>
                  <SelectItem value="utilities">Utilities & Maintenance</SelectItem>
                  <SelectItem value="planning">Urban Planning & Zoning</SelectItem>
                  <SelectItem value="other">Other Municipal Services</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              <Label htmlFor="urgency" className="text-sm font-medium">
                Priority Level *
              </Label>
              <Select value={formData.urgency} onValueChange={(value) => setFormData({ ...formData, urgency: value })}>
                <SelectTrigger className="h-11 bg-background/50 border-border/50">
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-success rounded-full"></div>
                      Low Priority
                    </div>
                  </SelectItem>
                  <SelectItem value="medium">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-warning rounded-full"></div>
                      Medium Priority
                    </div>
                  </SelectItem>
                  <SelectItem value="high">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-destructive rounded-full"></div>
                      High Priority
                    </div>
                  </SelectItem>
                  <SelectItem value="critical">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-3 h-3 text-destructive" />
                      Critical
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-3">
            <Label htmlFor="location" className="text-sm font-medium">
              Location *
            </Label>
            <div className="relative">
              <Input
                id="location"
                placeholder="Specific address, intersection, or landmark"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="h-11 pl-11 bg-background/50 border-border/50"
                required
              />
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
          </div>

          <div className="space-y-3">
            <Label htmlFor="description" className="text-sm font-medium">
              Detailed Description *
            </Label>
            <Textarea
              id="description"
              placeholder="Provide comprehensive details about the issue, including any relevant context, impact, and suggested solutions..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={5}
              className="bg-background/50 border-border/50 resize-none"
              required
            />
          </div>

          <div className="space-y-3">
            <Label className="text-sm font-medium">Supporting Documentation</Label>
            <div className="border-2 border-dashed border-border/50 rounded-lg p-6 text-center hover:border-border transition-colors">
              <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">
                Drag and drop files here, or <span className="text-primary cursor-pointer">browse</span>
              </p>
              <p className="text-xs text-muted-foreground mt-1">Supports: Images, PDFs, Documents (Max 10MB)</p>
            </div>
          </div>

          <Button type="submit" className="w-full h-11 text-base font-medium">
            Submit Issue Report
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
