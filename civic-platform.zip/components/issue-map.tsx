"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Navigation } from "lucide-react"

const mapPins = [
  { id: 1, x: 25, y: 30, urgency: "High", title: "Broken streetlight" },
  { id: 2, x: 60, y: 45, urgency: "Medium", title: "Pothole issue" },
  { id: 3, x: 40, y: 70, urgency: "Low", title: "Overflowing trash" },
  { id: 4, x: 75, y: 25, urgency: "Critical", title: "Water main leak" },
  { id: 5, x: 15, y: 60, urgency: "Medium", title: "Damaged sidewalk" },
  { id: 6, x: 85, y: 55, urgency: "Low", title: "Graffiti removal" },
]

const getPinColor = (urgency: string) => {
  switch (urgency.toLowerCase()) {
    case "critical":
      return "text-red-600"
    case "high":
      return "text-orange-500"
    case "medium":
      return "text-yellow-500"
    case "low":
      return "text-green-500"
    default:
      return "text-gray-500"
  }
}

export function IssueMap() {
  return (
    <Card className="h-fit">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Navigation className="h-5 w-5 text-primary" />
          Issue Locations
        </CardTitle>
        <CardDescription>Interactive map showing reported issues in your area</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="relative bg-muted/30 rounded-lg h-80 overflow-hidden">
          {/* Mock map background */}
          <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-secondary/30">
            <div className="absolute inset-4 border-2 border-dashed border-border/30 rounded-lg flex items-center justify-center">
              <span className="text-muted-foreground text-sm">Interactive Map Area</span>
            </div>
          </div>

          {/* Map pins */}
          {mapPins.map((pin) => (
            <div
              key={pin.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
              style={{ left: `${pin.x}%`, top: `${pin.y}%` }}
            >
              <MapPin className={`h-6 w-6 ${getPinColor(pin.urgency)} hover:scale-110 transition-transform`} />
              <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="bg-popover border border-border rounded-lg p-2 shadow-lg whitespace-nowrap">
                  <p className="text-xs font-medium">{pin.title}</p>
                  <Badge className={`text-xs mt-1 ${getPinColor(pin.urgency)}`} variant="outline">
                    {pin.urgency}
                  </Badge>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <div className="flex items-center gap-1 text-xs">
            <MapPin className="h-3 w-3 text-red-600" />
            <span>Critical</span>
          </div>
          <div className="flex items-center gap-1 text-xs">
            <MapPin className="h-3 w-3 text-orange-500" />
            <span>High</span>
          </div>
          <div className="flex items-center gap-1 text-xs">
            <MapPin className="h-3 w-3 text-yellow-500" />
            <span>Medium</span>
          </div>
          <div className="flex items-center gap-1 text-xs">
            <MapPin className="h-3 w-3 text-green-500" />
            <span>Low</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
