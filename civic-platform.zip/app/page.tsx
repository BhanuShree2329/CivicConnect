import { Header } from "@/components/header"
import { IssueForm } from "@/components/issue-form"
import { IssueDashboard } from "@/components/issue-dashboard"
import { IssueMap } from "@/components/issue-map"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background grid-pattern">
      <Header />
      <main className="container mx-auto px-6 py-12">
        <section className="text-center space-y-6 mb-16 fade-in">
          <div className="space-y-4">
            <h1 className="text-5xl md:text-7xl font-bold text-balance text-foreground tracking-tight">
              {"Civic Operations"}
            </h1>
            <h2 className="text-2xl md:text-3xl font-medium text-muted-foreground">{"Enterprise Platform"}</h2>
          </div>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto text-pretty leading-relaxed">
            {
              "Advanced civic issue management system for government agencies and municipal operations. Streamline reporting, tracking, and resolution workflows."
            }
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-12 max-w-4xl mx-auto">
            <div className="text-center space-y-2">
              <div className="text-3xl font-bold text-primary">2,847</div>
              <div className="text-sm text-muted-foreground">Issues Resolved</div>
            </div>
            <div className="text-center space-y-2">
              <div className="text-3xl font-bold text-success">94%</div>
              <div className="text-sm text-muted-foreground">Resolution Rate</div>
            </div>
            <div className="text-center space-y-2">
              <div className="text-3xl font-bold text-info">12.5k</div>
              <div className="text-sm text-muted-foreground">Active Citizens</div>
            </div>
            <div className="text-center space-y-2">
              <div className="text-3xl font-bold text-warning">48h</div>
              <div className="text-sm text-muted-foreground">Avg Response</div>
            </div>
          </div>
        </section>

        <div className="grid xl:grid-cols-3 gap-8 mb-16">
          <div className="xl:col-span-2">
            <IssueForm />
          </div>
          <div>
            <IssueMap />
          </div>
        </div>

        <IssueDashboard />
      </main>
    </div>
  )
}
