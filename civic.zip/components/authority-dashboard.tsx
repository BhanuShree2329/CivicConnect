"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { useState } from "react"

const mockIssues = [
  {
    id: 1,
    title: "Water main leak flooding sidewalk",
    category: "Utilities",
    urgency: "Critical",
    location: "Pine Street near City Hall",
    description: "Water main break is flooding the sidewalk and affecting nearby businesses.",
    date: "2024-01-16",
    status: "In Progress",
    likes: 23,
    comments: 8,
    priority: 1,
    assignedDept: "Water Department",
    estimatedCost: "$15,000",
    affectedCitizens: 150,
  },
  {
    id: 2,
    title: "Broken streetlight on Main Street",
    category: "Infrastructure",
    urgency: "High",
    location: "123 Main Street",
    description: "The streetlight has been out for 3 days, creating safety concerns for pedestrians.",
    date: "2024-01-15",
    status: "In Progress",
    likes: 12,
    comments: 3,
    priority: 2,
    assignedDept: "Public Works",
    estimatedCost: "$800",
    affectedCitizens: 75,
  },
  {
    id: 3,
    title: "Pothole causing traffic issues",
    category: "Transportation",
    urgency: "Medium",
    location: "Oak Avenue & 5th Street",
    description: "Large pothole is causing vehicles to swerve and creating traffic congestion.",
    date: "2024-01-14",
    status: "Reported",
    likes: 8,
    comments: 5,
    priority: 3,
    assignedDept: "Transportation",
    estimatedCost: "$1,200",
    affectedCitizens: 200,
  },
  {
    id: 4,
    title: "Overflowing trash bins in Central Park",
    category: "Environment",
    urgency: "Low",
    location: "Central Park, Section B",
    description: "Multiple trash bins are overflowing, attracting pests and creating unsanitary conditions.",
    date: "2024-01-13",
    status: "Resolved",
    likes: 15,
    comments: 2,
    priority: 4,
    assignedDept: "Sanitation",
    estimatedCost: "$300",
    affectedCitizens: 50,
  },
]

const getUrgencyColor = (urgency: string) => {
  switch (urgency.toLowerCase()) {
    case "critical":
      return "bg-destructive text-destructive-foreground"
    case "high":
      return "bg-orange-500 text-white"
    case "medium":
      return "bg-yellow-500 text-white"
    case "low":
      return "bg-green-500 text-white"
    default:
      return "bg-secondary text-secondary-foreground"
  }
}

const getStatusColor = (status: string) => {
  switch (status.toLowerCase()) {
    case "resolved":
      return "bg-green-100 text-green-800 border-green-200"
    case "in progress":
      return "bg-blue-100 text-blue-800 border-blue-200"
    case "reported":
      return "bg-gray-100 text-gray-800 border-gray-200"
    default:
      return "bg-secondary text-secondary-foreground"
  }
}

const getPriorityColor = (priority: number) => {
  switch (priority) {
    case 1:
      return "bg-red-500 text-white"
    case 2:
      return "bg-orange-500 text-white"
    case 3:
      return "bg-yellow-500 text-white"
    default:
      return "bg-green-500 text-white"
  }
}

export function AuthorityDashboard() {
  const [issues, setIssues] = useState(mockIssues)
  const [sortBy, setSortBy] = useState("priority")
  const [filterStatus, setFilterStatus] = useState("all")

  const updatePriority = (issueId: number, direction: "up" | "down") => {
    setIssues((prev) =>
      prev.map((issue) => {
        if (issue.id === issueId) {
          const newPriority = direction === "up" ? Math.max(1, issue.priority - 1) : Math.min(10, issue.priority + 1)
          return { ...issue, priority: newPriority }
        }
        return issue
      }),
    )
  }

  const updateStatus = (issueId: number, newStatus: string) => {
    setIssues((prev) => prev.map((issue) => (issue.id === issueId ? { ...issue, status: newStatus } : issue)))
  }

  const filteredIssues = issues
    .filter((issue) => filterStatus === "all" || issue.status.toLowerCase() === filterStatus)
    .sort((a, b) => {
      switch (sortBy) {
        case "priority":
          return a.priority - b.priority
        case "urgency":
          const urgencyOrder = { critical: 1, high: 2, medium: 3, low: 4 }
          return (
            urgencyOrder[a.urgency.toLowerCase() as keyof typeof urgencyOrder] -
            urgencyOrder[b.urgency.toLowerCase() as keyof typeof urgencyOrder]
          )
        case "cost":
          return (
            Number.parseInt(a.estimatedCost.replace(/[$,]/g, "")) -
            Number.parseInt(b.estimatedCost.replace(/[$,]/g, ""))
          )
        case "impact":
          return b.affectedCitizens - a.affectedCitizens
        default:
          return 0
      }
    })

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/80 rounded-lg flex items-center justify-center">
            <span className="text-primary-foreground font-bold">⚠</span>
          </div>
          <div className="text-left">
            <h1 className="text-4xl font-bold text-foreground">Authority Dashboard</h1>
            <p className="text-muted-foreground">Task Prioritization & Resource Management</p>
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-destructive">1</div>
            <div className="text-sm text-muted-foreground">Critical Issues</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-orange-500">2</div>
            <div className="text-sm text-muted-foreground">In Progress</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-primary">$17,300</div>
            <div className="text-sm text-muted-foreground">Est. Budget</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-info">475</div>
            <div className="text-sm text-muted-foreground">Citizens Affected</div>
          </CardContent>
        </Card>
      </div>

      {/* Controls */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="flex gap-4">
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Sort by..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="priority">Priority Level</SelectItem>
              <SelectItem value="urgency">Urgency</SelectItem>
              <SelectItem value="cost">Estimated Cost</SelectItem>
              <SelectItem value="impact">Citizen Impact</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by status..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="reported">Reported</SelectItem>
              <SelectItem value="in progress">In Progress</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Input placeholder="Search issues..." className="max-w-sm" />
      </div>

      {/* Issues List */}
      <div className="space-y-4">
        {filteredIssues.map((issue) => (
          <Card key={issue.id} className="hover:shadow-lg transition-all duration-200">
            <CardHeader className="pb-4">
              <div className="flex items-start justify-between">
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <Badge className={getPriorityColor(issue.priority)}>P{issue.priority}</Badge>
                    <CardTitle className="text-xl">{issue.title}</CardTitle>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <span>📅</span>
                      {issue.date}
                    </div>
                    <div className="flex items-center gap-1">
                      <span>📍</span>
                      {issue.location}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => updatePriority(issue.id, "up")}
                    disabled={issue.priority === 1}
                  >
                    ↑
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => updatePriority(issue.id, "down")}
                    disabled={issue.priority === 10}
                  >
                    ↓
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">{issue.description}</p>

              <div className="grid md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium text-muted-foreground">Department</div>
                  <Badge variant="outline">{issue.assignedDept}</Badge>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium text-muted-foreground">Estimated Cost</div>
                  <div className="font-semibold text-primary">{issue.estimatedCost}</div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium text-muted-foreground">Citizens Affected</div>
                  <div className="flex items-center gap-1">
                    <span>👥</span>
                    <span className="font-semibold">{issue.affectedCitizens}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t">
                <div className="flex items-center gap-4">
                  <Badge className={getUrgencyColor(issue.urgency)}>{issue.urgency}</Badge>
                  <Select value={issue.status} onValueChange={(value) => updateStatus(issue.id, value)}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Reported">Reported</SelectItem>
                      <SelectItem value="In Progress">In Progress</SelectItem>
                      <SelectItem value="Resolved">Resolved</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <span>👍</span>
                    {issue.likes}
                  </div>
                  <div className="flex items-center gap-1">
                    <span>💬</span>
                    {issue.comments}
                  </div>
                  <Button variant="outline" size="sm">
                    <span className="mr-1">⏰</span>
                    Assign Timeline
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
