import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function Header() {
  return (
    <header className="border-b border-border bg-card/80 backdrop-blur-md sticky top-0 z-50">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-lg flex items-center justify-center shadow-lg">
              <span className="text-primary-foreground font-bold text-lg">CO</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground tracking-tight">Civic Operations</h1>
              <p className="text-xs text-muted-foreground">Enterprise Platform</p>
            </div>
          </div>

          <div className="hidden lg:flex items-center flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">🔍</span>
              <Input
                placeholder="Search issues, locations, or departments..."
                className="pl-10 bg-muted/50 border-border/50"
              />
            </div>
          </div>

          <nav className="hidden md:flex items-center space-x-8">
            <a href="/" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Dashboard
            </a>
            <a
              href="/authority"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Authority
            </a>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Analytics
            </a>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Reports
            </a>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Administration
            </a>
          </nav>

          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" className="relative hover:bg-accent">
              <span>🔔</span>
              <span className="absolute -top-1 -right-1 h-2 w-2 bg-destructive rounded-full"></span>
            </Button>
            <Button variant="ghost" size="icon" className="hover:bg-accent">
              <span>⚙️</span>
            </Button>
            <Button variant="ghost" size="icon" className="hover:bg-accent">
              <span>👤</span>
            </Button>
            <Button variant="ghost" size="icon" className="md:hidden">
              <span>☰</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}
