import { Header } from "@/components/header"
import { AuthorityDashboard } from "@/components/authority-dashboard"

export default function AuthorityPage() {
  return (
    <div className="min-h-screen bg-background grid-pattern">
      <Header />
      <main className="container mx-auto px-6 py-12">
        <AuthorityDashboard />
      </main>
    </div>
  )
}
